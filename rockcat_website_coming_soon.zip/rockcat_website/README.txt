ROCKCAT WEBSITE

Files:
- index.html: responsive landing page
- assets/rockcat-mascot.png: mascot artwork supplied by you
- assets/rockcat-banner.png: banner artwork supplied by you

Preview:
Open index.html in a modern browser.

Before publishing:
1. The official X and Telegram links you provided are prefilled.
2. The site marks the token as not launched yet. Do not add a Buy link or contract address until deployment is complete and the address has been verified.
2. The current form stores values in localStorage for that browser only. It is a local preview feature, not a server-side CMS.
3. For a live public site, replace the default empty link buttons with your official links directly in index.html (or connect the form to a backend/CMS). Do not publish a contract address until you have verified it.
4. Upload the entire folder, including assets, to your hosting provider.

No wallet connection is requested and no seed phrase/private key fields exist.
